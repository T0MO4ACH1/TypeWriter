let gameStarted = false;
const GLOBAL_TIMER = 80; // always 80 seconds per your request
let timeLeft = GLOBAL_TIMER;
let timerInterval;
let originalText = "";
let typedText = "";
let keyPressCount = 0;
let correctKeys = 0;
let startTime = 0;
let soundEnabled = true;
let capsActive = false;
let wpmHistory = [];
let timeHistory = [];
let wpmChart = null;
let score = 0;
let activeBuff = null;
let buffTimerInterval = null;

// Key mapping for virtual keyboard
const keyMap = new Map();

// Central mechanics object — easy place to apply buffs/nerfs
const gameMechanics = {
    timerBase: GLOBAL_TIMER,
    healthMax: 100,
    health: 100,
    healthLossPerWrong: 1, // not harsh — adjustable by buffs
    scorePerCorrectChar: 10,
    scoreMultiplier: 1, // buffs can change this
    buffsAllowed: 1 // only one at a time (UI enforces)
};

function initKeyboardMapping() {
    document.querySelectorAll('.key').forEach(key => {
        const keyValue = key.getAttribute('data-key');
        if (keyValue) {
            const normalizedKey = normalizeKey(keyValue);
            if (!keyMap.has(normalizedKey)) {
                keyMap.set(normalizedKey, []);
            }
            keyMap.get(normalizedKey).push(key);
        }
    });
}

function normalizeKey(key) {
    const mapping = {
        ' ': 'space',
        'Control': 'control',
        'Shift': 'shift',
        'Alt': 'alt',
        'Meta': 'meta',
        'Enter': 'enter',
        'Backspace': 'backspace',
        'Tab': 'tab',
        'CapsLock': 'capslock',
        'ContextMenu': 'contextmenu'
    };
    return mapping[key] || key.toLowerCase();
}

function highlightKey(key, isCorrect = null) {
    const normalizedKey = normalizeKey(key);
    const elements = keyMap.get(normalizedKey);

    if (elements) {
        elements.forEach(el => {
            el.classList.add('active');
            if (isCorrect === true) {
                el.classList.add('correct');
            } else if (isCorrect === false) {
                el.classList.add('incorrect');
            }

            setTimeout(() => {
                el.classList.remove('active', 'correct', 'incorrect');
            }, 100);
        });
    }
}

function playSound(type) {
    if (!soundEnabled) return;

    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    if (type === 'correct') {
        oscillator.frequency.value = 800;
        gainNode.gain.setValueAtTime(0.05, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.05);
    } else if (type === 'incorrect') {
        oscillator.frequency.value = 200;
        gainNode.gain.setValueAtTime(0.08, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
    }

    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.1);
}

function startTimer() {
    clearInterval(timerInterval);
    startTime = Date.now();
    wpmHistory = [];
    timeHistory = [];
    timeLeft = gameMechanics.timerBase;
    const timerEl = document.getElementById("timer");
    timerEl.textContent = timeLeft;

    timerInterval = setInterval(() => {
        timeLeft--;
        timerEl.textContent = timeLeft;

        const elapsed = (Date.now() - startTime) / 1000 / 60;
        const currentWpm = elapsed > 0 ? Math.round((typedText.length / 5) / elapsed) : 0;
        wpmHistory.push(currentWpm);
        timeHistory.push(Math.round(elapsed * 60));

        if (timeLeft <= 0 || gameMechanics.health <= 0) {
            clearInterval(timerInterval);
            evaluatePerformance();
        }
    }, 1000);
}

async function fetchParagraph() {
    // fixed timerBase already set; reinitialize
    gameMechanics.timerBase = GLOBAL_TIMER;
    gameMechanics.health = gameMechanics.healthMax;
    document.getElementById("health-fill").style.width = "100%";
    document.getElementById("score-display").textContent = "0";
    score = 0;

    // simulate reading selectedRound from localStorage (same as before)
    const selectedFile = localStorage.getItem('selectedRound'); // e.g. "technology.json"

    try {
        if (selectedFile) {
            const filePath = `../Round/${selectedFile}`;
            const res = await fetch(filePath);
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const jsonData = await res.json();

            if (jsonData.paragraphs && jsonData.paragraphs.length > 0) {
                const randomIndex = Math.floor(Math.random() * jsonData.paragraphs.length);
                originalText = jsonData.paragraphs[randomIndex]
                    .replace(/\s+/g, ' ')
                    .trim()
                    .substring(0, 300);
            } else {
                throw new Error("No paragraphs found in JSON");
            }
        } else {
            throw new Error("No round selected");
        }
    } catch (error) {
        console.error("Error fetching paragraph:", error);
        originalText = "the quick brown fox jumps over the lazy dog this is a fallback text for typing practice when the json is unavailable keep practicing to improve your typing speed and accuracy with consistent effort you will see improvement";
    }

    // reset typed state
    typedText = "";
    gameStarted = true;
    keyPressCount = 0;
    correctKeys = 0;

    document.getElementById("message").classList.add("hidden");

    // choose a temporary random buff and apply it (for now)
    applyRandomBuffTemporarily();

    startTimer();
    updateDisplay();
    updateStats();
}

/* Update text display with correct/incorrect classes */
function updateDisplay() {
    let display = "";

    for (let i = 0; i < originalText.length; i++) {
        const char = originalText[i];

        if (i < typedText.length) {
            const isCorrect = typedText[i] === char;
            display += `<span class="typed-char ${isCorrect ? 'correct-char' : 'incorrect-char'}">${char}</span>`;
        } else {
            display += `<span class="untyped-char">${char}</span>`;
        }
    }

    document.getElementById("mid").innerHTML = display;
    updateStats();
}

/* Update WPM, accuracy, score, health UI */
function updateStats() {
    const elapsed = gameStarted ? (Date.now() - startTime) / 1000 / 60 : 0;
    const wpm = elapsed > 0 ? Math.round((typedText.length / 5) / elapsed) : 0;

    let correct = 0;
    for (let i = 0; i < typedText.length && i < originalText.length; i++) {
        if (typedText[i] === originalText[i]) correct++;
    }
    const accuracy = typedText.length > 0 ? Math.round((correct / typedText.length) * 100) : 100;

    document.getElementById("wpm-display").textContent = wpm;
    document.getElementById("accuracy-display").textContent = accuracy + "%";
    document.getElementById("score-display").textContent = score;
    document.getElementById("health-fill").style.width = Math.max(0, (gameMechanics.health / gameMechanics.healthMax) * 100) + "%";
}

/* Chart creation (keeps your chart settings) */
function createWpmChart(wpmData, timeData) {
    const ctx = document.getElementById('wpmChart');

    if (wpmChart) {
        wpmChart.destroy();
    }

    wpmChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: timeData,
            datasets: [{
                label: 'WPM',
                data: wpmData,
                borderColor: '#e2b714',
                backgroundColor: 'rgba(226, 183, 20, 0.1)',
                tension: 0.4,
                fill: true,
                pointRadius: 3,
                pointHoverRadius: 5,
                pointBackgroundColor: '#e2b714',
                pointBorderColor: '#e2b714'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: '#2c2e31',
                    titleColor: '#e2b714',
                    bodyColor: '#d1d0c5',
                    borderColor: '#646669',
                    borderWidth: 1,
                    padding: 10,
                    displayColors: false,
                    callbacks: {
                        title: (context) => `${context[0].label}s`,
                        label: (context) => `${context.parsed.y} wpm`
                    }
                }
            },
            scales: {
                x: {
                    grid: { color: '#3a3c3f', drawBorder: false },
                    ticks: { color: '#646669', font: { family: 'Roboto Mono', size: 11 } },
                    title: { display: true, text: 'time (seconds)', color: '#646669', font: { family: 'Roboto Mono', size: 12 } }
                },
                y: {
                    grid: { color: '#3a3c3f', drawBorder: false },
                    ticks: { color: '#646669', font: { family: 'Roboto Mono', size: 11 } },
                    title: { display: true, text: 'words per minute', color: '#646669', font: { family: 'Roboto Mono', size: 12 } },
                    beginAtZero: true
                }
            }
        }
    });
}

/* End of round evaluation */
function evaluatePerformance() {
    clearInterval(timerInterval);
    if (buffTimerInterval) {
        clearInterval(buffTimerInterval);
        buffTimerInterval = null;
    }

    let correct = 0;
    const minLength = Math.min(typedText.length, originalText.length);
    for (let i = 0; i < minLength; i++) {
        if (typedText[i] === originalText[i]) correct++;
    }

    const accuracy = minLength > 0 ? Math.round((correct / minLength) * 100) : 0;
    const totalTime = gameMechanics.timerBase;
    const wpm = Math.round((typedText.length / 5) / (totalTime / 60));

    let msg = "";
    if (accuracy === 100) {
        msg = "perfect!";
    } else if (accuracy >= 95) {
        msg = "excellent!";
    } else if (accuracy >= 85) {
        msg = "great!";
    } else if (accuracy >= 70) {
        msg = "good!";
    } else {
        msg = "keep practicing!";
    }

    document.getElementById("message-text").textContent = msg;
    document.getElementById("final-wpm").textContent = wpm;
    document.getElementById("final-accuracy").textContent = accuracy + "%";
    document.getElementById("final-score").textContent = score;


    const coinsEarned = Math.floor(score / 100) * 5;

    // show coins and chars
    document.getElementById("final-chars").textContent = `${typedText.length}/${originalText.length}`;
    const finalCoinsEl = document.getElementById("final-coins");
    if (finalCoinsEl) finalCoinsEl.textContent = coinsEarned;

    // persist coins to localStorage
    const stored = parseInt(localStorage.getItem('playerCoins') || '0', 10);
    const newTotal = stored + coinsEarned;
    localStorage.setItem('playerCoins', String(newTotal));

    // optional
    localStorage.setItem('lastSessionCoins', String(coinsEarned));
    localStorage.setItem('lastSessionScore', String(score));

    createWpmChart(wpmHistory, timeHistory);

    document.getElementById("message").classList.remove("hidden");
}

/* Called when user clicks next at end of round.
   Per your request, this goes to ./Shop/shop.html */
function closeMessageAndGoToShop() {
    // ensure we persist results to localStorage for shop to read
    localStorage.setItem('lastSessionScore', String(score));

    // write playerCoins already happens earlier when the round ends,
    // but ensure it's present (defensive)
    if (!localStorage.getItem('playerCoins')) {
        localStorage.setItem('playerCoins', '0');
    }

    // navigate to shop in the same folder (adjust if your file structure differs)
    window.location.href = '../Shop/shop.html';
}

/* Choose and apply a temporary random buff for demo purposes.
   Buffs alter gameMechanics so they can be stacked/changed later. */
function applyRandomBuffTemporarily() {
    // clear any previous buff
    activeBuff = null;
    if (buffTimerInterval) {
        clearInterval(buffTimerInterval);
        buffTimerInterval = null;
    }
    // sample buff pool
    const buffs = [
        { id: 'doubleScore', name: 'Double Score', duration: 20, apply: () => { gameMechanics.scoreMultiplier = 2; }, revert: () => { gameMechanics.scoreMultiplier = 1; } },
        { id: 'gentle', name: 'Gentle: -50% health loss', duration: 20, apply: () => { gameMechanics.healthLossPerWrong = Math.max(0.2, gameMechanics.healthLossPerWrong * 0.5); }, revert: () => { gameMechanics.healthLossPerWrong = 1; } },
        { id: 'shortenTimer', name: 'Quick Round -10s', duration: 20, apply: () => { gameMechanics.timerBase = Math.max(20, gameMechanics.timerBase - 10); }, revert: () => { gameMechanics.timerBase = GLOBAL_TIMER; } }
    ];

    // pick one at random for demo
    const pick = buffs[Math.floor(Math.random() * buffs.length)];
    activeBuff = { ...pick, remaining: pick.duration };
    // apply immediately
    pick.apply();

    // show in UI
    document.getElementById('buff-window').textContent = pick.name;
    document.getElementById('buff-duration').textContent = `${pick.duration}s`;

    // countdown display and automatic revert on expiry
    buffTimerInterval = setInterval(() => {
        activeBuff.remaining--;
        document.getElementById('buff-duration').textContent = `${activeBuff.remaining}s`;
        if (activeBuff.remaining <= 0) {
            // revert buff
            pick.revert();
            activeBuff = null;
            clearInterval(buffTimerInterval);
            buffTimerInterval = null;
            document.getElementById('buff-window').textContent = 'None';
            document.getElementById('buff-duration').textContent = '';
        }
    }, 1000);
}

/* Key handling (user input) */
document.addEventListener("keydown", e => {
    highlightKey(e.key);

    // start the game with ctrl (like before)
    if (!gameStarted && e.ctrlKey) {
        fetchParagraph();
        return;
    }

    if (!gameStarted || timeLeft <= 0) return;

    if (e.key === "CapsLock") {
        capsActive = !capsActive;
        const capsKeys = keyMap.get('capslock');
        if (capsKeys) {
            capsKeys.forEach(key => {
                key.classList.toggle('caps-active', capsActive);
            });
        }
        return;
    }

    if (e.key === "Backspace") {
        e.preventDefault();
        if (typedText.length > 0) {
            typedText = typedText.slice(0, -1);
            updateDisplay();
        }
        return;
    }

    if (e.key === "Tab") {
        e.preventDefault();
        return;
    }

    if (e.key.length === 1) {
        e.preventDefault();
        const expectedChar = originalText[typedText.length];
        const isCorrect = e.key === expectedChar;

        typedText += e.key;
        keyPressCount++;

        if (isCorrect) {
            correctKeys++;
            // increase score with multiplier
            score += Math.round(gameMechanics.scorePerCorrectChar * gameMechanics.scoreMultiplier);
            highlightKey(e.key, true);
            playSound('correct');
        } else {
            // deduct health based on mechanics
            gameMechanics.health = Math.max(0, gameMechanics.health - gameMechanics.healthLossPerWrong);
            highlightKey(e.key, false);
            playSound('incorrect');
        }

        updateDisplay();

        if (typedText.length >= originalText.length) {
            evaluatePerformance();
        }
    }
});

/* Toggle sound */
document.getElementById('sound-toggle').addEventListener('click', () => {
    soundEnabled = !soundEnabled;
    const btn = document.getElementById('sound-toggle');
    btn.style.opacity = soundEnabled ? '1' : '0.3';
});

/* Next button -> go to shop */
document.getElementById('next-button').addEventListener('click', () => {
    closeMessageAndGoToShop();
});

/* Initialize keyboard mapping on DOM load */
document.addEventListener('DOMContentLoaded', () => {
    initKeyboardMapping();
    // initialize UI values
    document.getElementById("timer").textContent = GLOBAL_TIMER;
    document.getElementById("score-display").textContent = "0";
    document.getElementById("health-fill").style.width = "100%";
});
